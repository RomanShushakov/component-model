#[allow(dead_code)]
pub mod docs {
    #[allow(dead_code)]
    pub mod calculator {
        #[allow(dead_code, clippy::all)]
        pub mod calculate {
            #[used]
            #[doc(hidden)]
            static __FORCE_SECTION_REF: fn() = super::super::super::__link_custom_section_describing_imports;
            use super::super::super::_rt;
            #[repr(u8)]
            #[derive(Clone, Copy, Eq, Ord, PartialEq, PartialOrd)]
            pub enum Op {
                Add,
                Subtract,
                Multiply,
                Divide,
                DivideJco,
            }
            impl ::core::fmt::Debug for Op {
                fn fmt(
                    &self,
                    f: &mut ::core::fmt::Formatter<'_>,
                ) -> ::core::fmt::Result {
                    match self {
                        Op::Add => f.debug_tuple("Op::Add").finish(),
                        Op::Subtract => f.debug_tuple("Op::Subtract").finish(),
                        Op::Multiply => f.debug_tuple("Op::Multiply").finish(),
                        Op::Divide => f.debug_tuple("Op::Divide").finish(),
                        Op::DivideJco => f.debug_tuple("Op::DivideJco").finish(),
                    }
                }
            }
            impl Op {
                #[doc(hidden)]
                pub unsafe fn _lift(val: u8) -> Op {
                    if !cfg!(debug_assertions) {
                        return ::core::mem::transmute(val);
                    }
                    match val {
                        0 => Op::Add,
                        1 => Op::Subtract,
                        2 => Op::Multiply,
                        3 => Op::Divide,
                        4 => Op::DivideJco,
                        _ => panic!("invalid enum discriminant"),
                    }
                }
            }
            #[allow(unused_unsafe, clippy::all)]
            pub fn eval_expression(op: Op, x: f32, y: f32) -> Result<f32, _rt::String> {
                unsafe {
                    #[repr(align(4))]
                    struct RetArea([::core::mem::MaybeUninit<u8>; 12]);
                    let mut ret_area = RetArea([::core::mem::MaybeUninit::uninit(); 12]);
                    let ptr0 = ret_area.0.as_mut_ptr().cast::<u8>();
                    #[cfg(target_arch = "wasm32")]
                    #[link(wasm_import_module = "docs:calculator/calculate@0.1.0")]
                    extern "C" {
                        #[link_name = "eval-expression"]
                        fn wit_import(_: i32, _: f32, _: f32, _: *mut u8);
                    }
                    #[cfg(not(target_arch = "wasm32"))]
                    fn wit_import(_: i32, _: f32, _: f32, _: *mut u8) {
                        unreachable!()
                    }
                    wit_import(
                        op.clone() as i32,
                        _rt::as_f32(&x),
                        _rt::as_f32(&y),
                        ptr0,
                    );
                    let l1 = i32::from(*ptr0.add(0).cast::<u8>());
                    match l1 {
                        0 => {
                            let e = {
                                let l2 = *ptr0.add(4).cast::<f32>();
                                l2
                            };
                            Ok(e)
                        }
                        1 => {
                            let e = {
                                let l3 = *ptr0.add(4).cast::<*mut u8>();
                                let l4 = *ptr0.add(8).cast::<usize>();
                                let len5 = l4;
                                let bytes5 = _rt::Vec::from_raw_parts(
                                    l3.cast(),
                                    len5,
                                    len5,
                                );
                                _rt::string_lift(bytes5)
                            };
                            Err(e)
                        }
                        _ => _rt::invalid_enum_discriminant(),
                    }
                }
            }
        }
    }
}
mod _rt {
    pub use alloc_crate::string::String;
    pub fn as_f32<T: AsF32>(t: T) -> f32 {
        t.as_f32()
    }
    pub trait AsF32 {
        fn as_f32(self) -> f32;
    }
    impl<'a, T: Copy + AsF32> AsF32 for &'a T {
        fn as_f32(self) -> f32 {
            (*self).as_f32()
        }
    }
    impl AsF32 for f32 {
        #[inline]
        fn as_f32(self) -> f32 {
            self as f32
        }
    }
    pub use alloc_crate::vec::Vec;
    pub unsafe fn string_lift(bytes: Vec<u8>) -> String {
        if cfg!(debug_assertions) {
            String::from_utf8(bytes).unwrap()
        } else {
            String::from_utf8_unchecked(bytes)
        }
    }
    pub unsafe fn invalid_enum_discriminant<T>() -> T {
        if cfg!(debug_assertions) {
            panic!("invalid enum discriminant")
        } else {
            core::hint::unreachable_unchecked()
        }
    }
    extern crate alloc as alloc_crate;
}
#[cfg(target_arch = "wasm32")]
#[link_section = "component-type:wit-bindgen:0.31.0:docs:calculator@0.1.0:app:encoded world"]
#[doc(hidden)]
pub static __WIT_BINDGEN_COMPONENT_TYPE: [u8; 289] = *b"\
\0asm\x0d\0\x01\0\0\x19\x16wit-component-encoding\x04\0\x07\xa7\x01\x01A\x02\x01\
A\x02\x01B\x05\x01m\x05\x03add\x08subtract\x08multiply\x06divide\x0adivide-jco\x04\
\0\x02op\x03\0\0\x01j\x01v\x01s\x01@\x03\x02op\x01\x01xv\x01yv\0\x02\x04\0\x0fev\
al-expression\x01\x03\x03\x01\x1fdocs:calculator/calculate@0.1.0\x05\0\x04\x01\x19\
docs:calculator/app@0.1.0\x04\0\x0b\x09\x01\0\x03app\x03\0\0\0G\x09producers\x01\
\x0cprocessed-by\x02\x0dwit-component\x070.216.0\x10wit-bindgen-rust\x060.31.0";
#[inline(never)]
#[doc(hidden)]
pub fn __link_custom_section_describing_imports() {
    wit_bindgen_rt::maybe_link_cabi_realloc();
}
