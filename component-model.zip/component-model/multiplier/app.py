import multiplier

class Multiply(multiplier.Multiplier):
    def multiply(self, a: float, b: float) -> float:
        return a * b
