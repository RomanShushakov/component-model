#[allow(dead_code)]
pub mod docs {
    #[allow(dead_code)]
    pub mod adder {
        #[allow(dead_code, clippy::all)]
        pub mod add {
            #[used]
            #[doc(hidden)]
            static __FORCE_SECTION_REF: fn() = super::super::super::__link_custom_section_describing_imports;
            use super::super::super::_rt;
            #[allow(unused_unsafe, clippy::all)]
            pub fn add(a: f32, b: f32) -> Result<f32, _rt::String> {
                unsafe {
                    #[repr(align(4))]
                    struct RetArea([::core::mem::MaybeUninit<u8>; 12]);
                    let mut ret_area = RetArea([::core::mem::MaybeUninit::uninit(); 12]);
                    let ptr0 = ret_area.0.as_mut_ptr().cast::<u8>();
                    #[cfg(target_arch = "wasm32")]
                    #[link(wasm_import_module = "docs:adder/add@0.1.0")]
                    extern "C" {
                        #[link_name = "add"]
                        fn wit_import(_: f32, _: f32, _: *mut u8);
                    }
                    #[cfg(not(target_arch = "wasm32"))]
                    fn wit_import(_: f32, _: f32, _: *mut u8) {
                        unreachable!()
                    }
                    wit_import(_rt::as_f32(&a), _rt::as_f32(&b), ptr0);
                    let l1 = i32::from(*ptr0.add(0).cast::<u8>());
                    match l1 {
                        0 => {
                            let e = {
                                let l2 = *ptr0.add(4).cast::<f32>();
                                l2
                            };
                            Ok(e)
                        }
                        1 => {
                            let e = {
                                let l3 = *ptr0.add(4).cast::<*mut u8>();
                                let l4 = *ptr0.add(8).cast::<usize>();
                                let len5 = l4;
                                let bytes5 = _rt::Vec::from_raw_parts(
                                    l3.cast(),
                                    len5,
                                    len5,
                                );
                                _rt::string_lift(bytes5)
                            };
                            Err(e)
                        }
                        _ => _rt::invalid_enum_discriminant(),
                    }
                }
            }
        }
    }
    #[allow(dead_code)]
    pub mod divider {
        #[allow(dead_code, clippy::all)]
        pub mod divide {
            #[used]
            #[doc(hidden)]
            static __FORCE_SECTION_REF: fn() = super::super::super::__link_custom_section_describing_imports;
            use super::super::super::_rt;
            #[allow(unused_unsafe, clippy::all)]
            pub fn divide(a: f32, b: f32) -> Result<f32, _rt::String> {
                unsafe {
                    #[repr(align(4))]
                    struct RetArea([::core::mem::MaybeUninit<u8>; 12]);
                    let mut ret_area = RetArea([::core::mem::MaybeUninit::uninit(); 12]);
                    let ptr0 = ret_area.0.as_mut_ptr().cast::<u8>();
                    #[cfg(target_arch = "wasm32")]
                    #[link(wasm_import_module = "docs:divider/divide@0.1.0")]
                    extern "C" {
                        #[link_name = "divide"]
                        fn wit_import(_: f32, _: f32, _: *mut u8);
                    }
                    #[cfg(not(target_arch = "wasm32"))]
                    fn wit_import(_: f32, _: f32, _: *mut u8) {
                        unreachable!()
                    }
                    wit_import(_rt::as_f32(&a), _rt::as_f32(&b), ptr0);
                    let l1 = i32::from(*ptr0.add(0).cast::<u8>());
                    match l1 {
                        0 => {
                            let e = {
                                let l2 = *ptr0.add(4).cast::<f32>();
                                l2
                            };
                            Ok(e)
                        }
                        1 => {
                            let e = {
                                let l3 = *ptr0.add(4).cast::<*mut u8>();
                                let l4 = *ptr0.add(8).cast::<usize>();
                                let len5 = l4;
                                let bytes5 = _rt::Vec::from_raw_parts(
                                    l3.cast(),
                                    len5,
                                    len5,
                                );
                                _rt::string_lift(bytes5)
                            };
                            Err(e)
                        }
                        _ => _rt::invalid_enum_discriminant(),
                    }
                }
            }
        }
    }
    #[allow(dead_code)]
    pub mod divider_jco {
        #[allow(dead_code, clippy::all)]
        pub mod divide_jco {
            #[used]
            #[doc(hidden)]
            static __FORCE_SECTION_REF: fn() = super::super::super::__link_custom_section_describing_imports;
            use super::super::super::_rt;
            #[allow(unused_unsafe, clippy::all)]
            pub fn divide_jco(a: f32, b: f32) -> Result<f32, _rt::String> {
                unsafe {
                    #[repr(align(4))]
                    struct RetArea([::core::mem::MaybeUninit<u8>; 12]);
                    let mut ret_area = RetArea([::core::mem::MaybeUninit::uninit(); 12]);
                    let ptr0 = ret_area.0.as_mut_ptr().cast::<u8>();
                    #[cfg(target_arch = "wasm32")]
                    #[link(wasm_import_module = "docs:divider-jco/divide-jco@0.1.0")]
                    extern "C" {
                        #[link_name = "divide-jco"]
                        fn wit_import(_: f32, _: f32, _: *mut u8);
                    }
                    #[cfg(not(target_arch = "wasm32"))]
                    fn wit_import(_: f32, _: f32, _: *mut u8) {
                        unreachable!()
                    }
                    wit_import(_rt::as_f32(&a), _rt::as_f32(&b), ptr0);
                    let l1 = i32::from(*ptr0.add(0).cast::<u8>());
                    match l1 {
                        0 => {
                            let e = {
                                let l2 = *ptr0.add(4).cast::<f32>();
                                l2
                            };
                            Ok(e)
                        }
                        1 => {
                            let e = {
                                let l3 = *ptr0.add(4).cast::<*mut u8>();
                                let l4 = *ptr0.add(8).cast::<usize>();
                                let len5 = l4;
                                let bytes5 = _rt::Vec::from_raw_parts(
                                    l3.cast(),
                                    len5,
                                    len5,
                                );
                                _rt::string_lift(bytes5)
                            };
                            Err(e)
                        }
                        _ => _rt::invalid_enum_discriminant(),
                    }
                }
            }
        }
    }
    #[allow(dead_code)]
    pub mod multiplier {
        #[allow(dead_code, clippy::all)]
        pub mod multiply {
            #[used]
            #[doc(hidden)]
            static __FORCE_SECTION_REF: fn() = super::super::super::__link_custom_section_describing_imports;
            use super::super::super::_rt;
            #[allow(unused_unsafe, clippy::all)]
            pub fn multiply(a: f32, b: f32) -> Result<f32, _rt::String> {
                unsafe {
                    #[repr(align(4))]
                    struct RetArea([::core::mem::MaybeUninit<u8>; 12]);
                    let mut ret_area = RetArea([::core::mem::MaybeUninit::uninit(); 12]);
                    let ptr0 = ret_area.0.as_mut_ptr().cast::<u8>();
                    #[cfg(target_arch = "wasm32")]
                    #[link(wasm_import_module = "docs:multiplier/multiply@0.1.0")]
                    extern "C" {
                        #[link_name = "multiply"]
                        fn wit_import(_: f32, _: f32, _: *mut u8);
                    }
                    #[cfg(not(target_arch = "wasm32"))]
                    fn wit_import(_: f32, _: f32, _: *mut u8) {
                        unreachable!()
                    }
                    wit_import(_rt::as_f32(&a), _rt::as_f32(&b), ptr0);
                    let l1 = i32::from(*ptr0.add(0).cast::<u8>());
                    match l1 {
                        0 => {
                            let e = {
                                let l2 = *ptr0.add(4).cast::<f32>();
                                l2
                            };
                            Ok(e)
                        }
                        1 => {
                            let e = {
                                let l3 = *ptr0.add(4).cast::<*mut u8>();
                                let l4 = *ptr0.add(8).cast::<usize>();
                                let len5 = l4;
                                let bytes5 = _rt::Vec::from_raw_parts(
                                    l3.cast(),
                                    len5,
                                    len5,
                                );
                                _rt::string_lift(bytes5)
                            };
                            Err(e)
                        }
                        _ => _rt::invalid_enum_discriminant(),
                    }
                }
            }
        }
    }
    #[allow(dead_code)]
    pub mod subtractor {
        #[allow(dead_code, clippy::all)]
        pub mod subtract {
            #[used]
            #[doc(hidden)]
            static __FORCE_SECTION_REF: fn() = super::super::super::__link_custom_section_describing_imports;
            use super::super::super::_rt;
            #[allow(unused_unsafe, clippy::all)]
            pub fn subtract(a: f32, b: f32) -> Result<f32, _rt::String> {
                unsafe {
                    #[repr(align(4))]
                    struct RetArea([::core::mem::MaybeUninit<u8>; 12]);
                    let mut ret_area = RetArea([::core::mem::MaybeUninit::uninit(); 12]);
                    let ptr0 = ret_area.0.as_mut_ptr().cast::<u8>();
                    #[cfg(target_arch = "wasm32")]
                    #[link(wasm_import_module = "docs:subtractor/subtract@0.1.0")]
                    extern "C" {
                        #[link_name = "subtract"]
                        fn wit_import(_: f32, _: f32, _: *mut u8);
                    }
                    #[cfg(not(target_arch = "wasm32"))]
                    fn wit_import(_: f32, _: f32, _: *mut u8) {
                        unreachable!()
                    }
                    wit_import(_rt::as_f32(&a), _rt::as_f32(&b), ptr0);
                    let l1 = i32::from(*ptr0.add(0).cast::<u8>());
                    match l1 {
                        0 => {
                            let e = {
                                let l2 = *ptr0.add(4).cast::<f32>();
                                l2
                            };
                            Ok(e)
                        }
                        1 => {
                            let e = {
                                let l3 = *ptr0.add(4).cast::<*mut u8>();
                                let l4 = *ptr0.add(8).cast::<usize>();
                                let len5 = l4;
                                let bytes5 = _rt::Vec::from_raw_parts(
                                    l3.cast(),
                                    len5,
                                    len5,
                                );
                                _rt::string_lift(bytes5)
                            };
                            Err(e)
                        }
                        _ => _rt::invalid_enum_discriminant(),
                    }
                }
            }
        }
    }
}
#[allow(dead_code)]
pub mod exports {
    #[allow(dead_code)]
    pub mod docs {
        #[allow(dead_code)]
        pub mod calculator {
            #[allow(dead_code, clippy::all)]
            pub mod calculate {
                #[used]
                #[doc(hidden)]
                static __FORCE_SECTION_REF: fn() = super::super::super::super::__link_custom_section_describing_imports;
                use super::super::super::super::_rt;
                #[repr(u8)]
                #[derive(Clone, Copy, Eq, Ord, PartialEq, PartialOrd)]
                pub enum Op {
                    Add,
                    Subtract,
                    Multiply,
                    Divide,
                    DivideJco,
                }
                impl ::core::fmt::Debug for Op {
                    fn fmt(
                        &self,
                        f: &mut ::core::fmt::Formatter<'_>,
                    ) -> ::core::fmt::Result {
                        match self {
                            Op::Add => f.debug_tuple("Op::Add").finish(),
                            Op::Subtract => f.debug_tuple("Op::Subtract").finish(),
                            Op::Multiply => f.debug_tuple("Op::Multiply").finish(),
                            Op::Divide => f.debug_tuple("Op::Divide").finish(),
                            Op::DivideJco => f.debug_tuple("Op::DivideJco").finish(),
                        }
                    }
                }
                impl Op {
                    #[doc(hidden)]
                    pub unsafe fn _lift(val: u8) -> Op {
                        if !cfg!(debug_assertions) {
                            return ::core::mem::transmute(val);
                        }
                        match val {
                            0 => Op::Add,
                            1 => Op::Subtract,
                            2 => Op::Multiply,
                            3 => Op::Divide,
                            4 => Op::DivideJco,
                            _ => panic!("invalid enum discriminant"),
                        }
                    }
                }
                #[doc(hidden)]
                #[allow(non_snake_case)]
                pub unsafe fn _export_eval_expression_cabi<T: Guest>(
                    arg0: i32,
                    arg1: f32,
                    arg2: f32,
                ) -> *mut u8 {
                    #[cfg(target_arch = "wasm32")] _rt::run_ctors_once();
                    let result0 = T::eval_expression(Op::_lift(arg0 as u8), arg1, arg2);
                    let ptr1 = _RET_AREA.0.as_mut_ptr().cast::<u8>();
                    match result0 {
                        Ok(e) => {
                            *ptr1.add(0).cast::<u8>() = (0i32) as u8;
                            *ptr1.add(4).cast::<f32>() = _rt::as_f32(e);
                        }
                        Err(e) => {
                            *ptr1.add(0).cast::<u8>() = (1i32) as u8;
                            let vec2 = (e.into_bytes()).into_boxed_slice();
                            let ptr2 = vec2.as_ptr().cast::<u8>();
                            let len2 = vec2.len();
                            ::core::mem::forget(vec2);
                            *ptr1.add(8).cast::<usize>() = len2;
                            *ptr1.add(4).cast::<*mut u8>() = ptr2.cast_mut();
                        }
                    };
                    ptr1
                }
                #[doc(hidden)]
                #[allow(non_snake_case)]
                pub unsafe fn __post_return_eval_expression<T: Guest>(arg0: *mut u8) {
                    let l0 = i32::from(*arg0.add(0).cast::<u8>());
                    match l0 {
                        0 => {}
                        _ => {
                            let l1 = *arg0.add(4).cast::<*mut u8>();
                            let l2 = *arg0.add(8).cast::<usize>();
                            _rt::cabi_dealloc(l1, l2, 1);
                        }
                    }
                }
                pub trait Guest {
                    fn eval_expression(
                        op: Op,
                        x: f32,
                        y: f32,
                    ) -> Result<f32, _rt::String>;
                }
                #[doc(hidden)]
                macro_rules! __export_docs_calculator_calculate_0_1_0_cabi {
                    ($ty:ident with_types_in $($path_to_types:tt)*) => {
                        const _ : () = { #[export_name =
                        "docs:calculator/calculate@0.1.0#eval-expression"] unsafe extern
                        "C" fn export_eval_expression(arg0 : i32, arg1 : f32, arg2 :
                        f32,) -> * mut u8 { $($path_to_types)*::
                        _export_eval_expression_cabi::<$ty > (arg0, arg1, arg2) }
                        #[export_name =
                        "cabi_post_docs:calculator/calculate@0.1.0#eval-expression"]
                        unsafe extern "C" fn _post_return_eval_expression(arg0 : * mut
                        u8,) { $($path_to_types)*:: __post_return_eval_expression::<$ty >
                        (arg0) } };
                    };
                }
                #[doc(hidden)]
                pub(crate) use __export_docs_calculator_calculate_0_1_0_cabi;
                #[repr(align(4))]
                struct _RetArea([::core::mem::MaybeUninit<u8>; 12]);
                static mut _RET_AREA: _RetArea = _RetArea(
                    [::core::mem::MaybeUninit::uninit(); 12],
                );
            }
        }
    }
}
mod _rt {
    pub use alloc_crate::string::String;
    pub fn as_f32<T: AsF32>(t: T) -> f32 {
        t.as_f32()
    }
    pub trait AsF32 {
        fn as_f32(self) -> f32;
    }
    impl<'a, T: Copy + AsF32> AsF32 for &'a T {
        fn as_f32(self) -> f32 {
            (*self).as_f32()
        }
    }
    impl AsF32 for f32 {
        #[inline]
        fn as_f32(self) -> f32 {
            self as f32
        }
    }
    pub use alloc_crate::vec::Vec;
    pub unsafe fn string_lift(bytes: Vec<u8>) -> String {
        if cfg!(debug_assertions) {
            String::from_utf8(bytes).unwrap()
        } else {
            String::from_utf8_unchecked(bytes)
        }
    }
    pub unsafe fn invalid_enum_discriminant<T>() -> T {
        if cfg!(debug_assertions) {
            panic!("invalid enum discriminant")
        } else {
            core::hint::unreachable_unchecked()
        }
    }
    #[cfg(target_arch = "wasm32")]
    pub fn run_ctors_once() {
        wit_bindgen_rt::run_ctors_once();
    }
    pub unsafe fn cabi_dealloc(ptr: *mut u8, size: usize, align: usize) {
        if size == 0 {
            return;
        }
        let layout = alloc::Layout::from_size_align_unchecked(size, align);
        alloc::dealloc(ptr, layout);
    }
    extern crate alloc as alloc_crate;
    pub use alloc_crate::alloc;
}
/// Generates `#[no_mangle]` functions to export the specified type as the
/// root implementation of all generated traits.
///
/// For more information see the documentation of `wit_bindgen::generate!`.
///
/// ```rust
/// # macro_rules! export{ ($($t:tt)*) => (); }
/// # trait Guest {}
/// struct MyType;
///
/// impl Guest for MyType {
///     // ...
/// }
///
/// export!(MyType);
/// ```
#[allow(unused_macros)]
#[doc(hidden)]
macro_rules! __export_calculator_impl {
    ($ty:ident) => {
        self::export!($ty with_types_in self);
    };
    ($ty:ident with_types_in $($path_to_types_root:tt)*) => {
        $($path_to_types_root)*::
        exports::docs::calculator::calculate::__export_docs_calculator_calculate_0_1_0_cabi!($ty
        with_types_in $($path_to_types_root)*:: exports::docs::calculator::calculate);
    };
}
#[doc(inline)]
pub(crate) use __export_calculator_impl as export;
#[cfg(target_arch = "wasm32")]
#[link_section = "component-type:wit-bindgen:0.31.0:docs:calculator@0.1.0:calculator:encoded world"]
#[doc(hidden)]
pub static __WIT_BINDGEN_COMPONENT_TYPE: [u8; 626] = *b"\
\0asm\x0d\0\x01\0\0\x19\x16wit-component-encoding\x04\0\x07\xf1\x03\x01A\x02\x01\
A\x0c\x01B\x03\x01j\x01v\x01s\x01@\x02\x01av\x01bv\0\0\x04\0\x03add\x01\x01\x03\x01\
\x14docs:adder/add@0.1.0\x05\0\x01B\x03\x01j\x01v\x01s\x01@\x02\x01av\x01bv\0\0\x04\
\0\x08subtract\x01\x01\x03\x01\x1edocs:subtractor/subtract@0.1.0\x05\x01\x01B\x03\
\x01j\x01v\x01s\x01@\x02\x01av\x01bv\0\0\x04\0\x08multiply\x01\x01\x03\x01\x1edo\
cs:multiplier/multiply@0.1.0\x05\x02\x01B\x03\x01j\x01v\x01s\x01@\x02\x01av\x01b\
v\0\0\x04\0\x06divide\x01\x01\x03\x01\x19docs:divider/divide@0.1.0\x05\x03\x01B\x03\
\x01j\x01v\x01s\x01@\x02\x01av\x01bv\0\0\x04\0\x0adivide-jco\x01\x01\x03\x01!doc\
s:divider-jco/divide-jco@0.1.0\x05\x04\x01B\x05\x01m\x05\x03add\x08subtract\x08m\
ultiply\x06divide\x0adivide-jco\x04\0\x02op\x03\0\0\x01j\x01v\x01s\x01@\x03\x02o\
p\x01\x01xv\x01yv\0\x02\x04\0\x0feval-expression\x01\x03\x04\x01\x1fdocs:calcula\
tor/calculate@0.1.0\x05\x05\x04\x01\x20docs:calculator/calculator@0.1.0\x04\0\x0b\
\x10\x01\0\x0acalculator\x03\0\0\0G\x09producers\x01\x0cprocessed-by\x02\x0dwit-\
component\x070.216.0\x10wit-bindgen-rust\x060.31.0";
#[inline(never)]
#[doc(hidden)]
pub fn __link_custom_section_describing_imports() {
    wit_bindgen_rt::maybe_link_cabi_realloc();
}
